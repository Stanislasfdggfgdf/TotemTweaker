package com.totemtweaker.totemtweaker.mixin;

import com.totemtweaker.totemtweaker.config.TotemTweakerConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(class_759.class)
public abstract class LivingEntityRendererMixin {

    private boolean totemtweaker$didPush = false;

    @Inject(
        method = "renderFirstPersonItem(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/util/Hand;FLnet/minecraft/item/ItemStack;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
        at = @At("HEAD")
    )
    private void totemtweaker$scaleTotemPre(
            class_742 player, float tickDelta, float pitch,
            class_1268 hand, float swingProgress, class_1799 item, float equipProgress,
            class_4587 matrices, class_4597 vertexConsumers, int light,
            CallbackInfo ci) {

        totemtweaker$didPush = false;
        if (item.method_31574(class_1802.field_8288)) {
            float s = TotemTweakerConfig.get().handScaleMultiplier();
            if (s < 0.9999f) {
                matrices.method_22903();
                matrices.method_22905(s, s, s);
                totemtweaker$didPush = true;
            }
        }
    }

    @Inject(
        method = "renderFirstPersonItem(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/util/Hand;FLnet/minecraft/item/ItemStack;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
        at = @At("RETURN")
    )
    private void totemtweaker$scaleTotemPost(
            class_742 player, float tickDelta, float pitch,
            class_1268 hand, float swingProgress, class_1799 item, float equipProgress,
            class_4587 matrices, class_4597 vertexConsumers, int light,
            CallbackInfo ci) {

        if (totemtweaker$didPush) {
            matrices.method_22909();
            totemtweaker$didPush = false;
        }
    }
}
