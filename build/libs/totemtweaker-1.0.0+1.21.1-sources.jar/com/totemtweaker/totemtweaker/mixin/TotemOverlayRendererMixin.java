package com.totemtweaker.totemtweaker.mixin;

import com.totemtweaker.totemtweaker.config.TotemTweakerConfig;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(class_329.class)
public abstract class TotemOverlayRendererMixin {

    private static final String TOTEM_TEXTURE_PATH = "totem_of_undying";

    @Inject(
        method = "renderOverlay(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/util/Identifier;F)V",
        at = @At("HEAD"),
        cancellable = true
    )
    private void totemtweaker$onRenderOverlay(class_332 context, class_2960 texture, float opacity, CallbackInfo ci) {
        if (!texture.method_12832().contains(TOTEM_TEXTURE_PATH)) return;

        TotemTweakerConfig cfg = TotemTweakerConfig.get();
        if (cfg.animationScale >= 1.0f && cfg.animationAlpha >= 1.0f) return;

        ci.cancel();

        float scale = Math.max(0f, Math.min(1f, cfg.animationScale));
        float alpha = Math.max(0f, Math.min(1f, cfg.animationAlpha)) * opacity;

        if (alpha <= 0f || scale <= 0f) return;

        class_310 client = class_310.method_1551();
        int screenWidth  = client.method_22683().method_4486();
        int screenHeight = client.method_22683().method_4502();

        int drawW = (int)(screenWidth  * scale);
        int drawH = (int)(screenHeight * scale);
        int x     = (screenWidth  - drawW) / 2;
        int y     = (screenHeight - drawH) / 2;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShaderColor(1f, 1f, 1f, alpha);

        context.method_25290(texture, x, y, 0, 0, drawW, drawH, drawW, drawH);

        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        RenderSystem.disableBlend();
    }
}
