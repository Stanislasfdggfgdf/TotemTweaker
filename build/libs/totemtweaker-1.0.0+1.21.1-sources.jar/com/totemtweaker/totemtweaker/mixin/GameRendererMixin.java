package com.totemtweaker.totemtweaker.mixin;

import com.totemtweaker.totemtweaker.config.TotemTweakerConfig;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1309;
import net.minecraft.class_702;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(class_702.class)
public abstract class GameRendererMixin {

    @Inject(
        method = "addTotemParticles",
        at = @At("HEAD"),
        cancellable = true,
        require = 0
    )
    private void totemtweaker$cancelTotemParticles(class_1309 entity, CallbackInfo ci) {
        if (TotemTweakerConfig.get().removeParticles) {
            ci.cancel();
        }
    }
}
